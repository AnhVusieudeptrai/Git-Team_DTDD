package com.example.app_ecotrack.adapters;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ActivityAdapter extends RecyclerView.Adapter<ActivityAdapter.ActivityViewHolder> {
    private Context context;
    private List<Activity> activityList;
    private OnActivityClickListener listener;

    public interface OnActivityClickListener {
        void onCompleteClick(Activity activity);
    }

    public ActivityAdapter(Context context, List<Activity> activityList, OnActivityClickListener listener) {
        this.context = context;
        this.activityList = activityList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ActivityViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_activity, parent, false);
        return new ActivityViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ActivityViewHolder holder, int position) {
        Activity activity = activityList.get(position);

        holder.tvName.setText(activity.getName());
        holder.tvDescription.setText(activity.getDescription());
        holder.tvPoints.setText("+" + activity.getPoints() + " điểm");
        holder.tvCategory.setText(getCategoryName(activity.getCategory()));

        // Set category color
        int color = getCategoryColor(activity.getCategory());
        holder.cardView.setCardBackgroundColor(color);

        // Handle complete button
        if (activity.isCompleted()) {
            holder.btnComplete.setEnabled(false);
            holder.btnComplete.setText("✓ Đã hoàn thành");
            holder.btnComplete.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#9E9E9E")
            ));
            holder.cardView.setAlpha(0.6f);
        } else {
            holder.btnComplete.setEnabled(true);
            holder.btnComplete.setText("Hoàn thành");
            holder.btnComplete.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#4CAF50")
            ));
            holder.cardView.setAlpha(1.0f);
        }

        holder.btnComplete.setOnClickListener(v -> {
            if (listener != null && !activity.isCompleted()) {
                listener.onCompleteClick(activity);
            }
        });
    }

    @Override
    public int getItemCount() {
        return activityList.size();
    }

    private String getCategoryName(String category) {
        switch (category) {
            case "transport": return "🚴 Giao thông";
            case "energy": return "💡 Năng lượng";
            case "water": return "💧 Nước";
            case "waste": return "♻️ Rác thải";
            case "green": return "🌳 Cây xanh";
            case "consumption": return "🛒 Tiêu dùng";
            default: return category;
        }
    }

    private int getCategoryColor(String category) {
        switch (category) {
            case "transport": return android.graphics.Color.parseColor("#E3F2FD");
            case "energy": return android.graphics.Color.parseColor("#FFF9C4");
            case "water": return android.graphics.Color.parseColor("#E0F7FA");
            case "waste": return android.graphics.Color.parseColor("#E8F5E9");
            case "green": return android.graphics.Color.parseColor("#E0F2F1");
            case "consumption": return android.graphics.Color.parseColor("#F3E5F5");
            default: return android.graphics.Color.parseColor("#F5F5F5");
        }
    }

    static class ActivityViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvName, tvDescription, tvPoints, tvCategory;
        Button btnComplete;

        public ActivityViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = (CardView) itemView;
            tvName = itemView.findViewById(R.id.tvActivityName);
            tvDescription = itemView.findViewById(R.id.tvActivityDescription);
            tvPoints = itemView.findViewById(R.id.tvActivityPoints);
            tvCategory = itemView.findViewById(R.id.tvActivityCategory);
            btnComplete = itemView.findViewById(R.id.btnComplete);
        }
    }
}