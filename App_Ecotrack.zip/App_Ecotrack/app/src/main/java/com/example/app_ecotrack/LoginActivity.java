package com.example.app_ecotrack;

public class LoginActivity {
}
