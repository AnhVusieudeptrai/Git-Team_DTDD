package com.example.app_ecotrack.adapters;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

public class RewardsActivity extends AppCompatActivity {
    private TextView tvUserPoints;
    private GridLayout gridRewards;
    private SharedPreferences prefs;
    private DatabaseHelper db;
    private int userId, userPoints;

    // Rewards data
    private static final String[][] REWARDS = {
            {"🛍️", "Túi vải EcoTrack", "100", "Túi vải thân thiện môi trường"},
            {"🍶", "Bình nước inox", "150", "Bình giữ nhiệt cao cấp"},
            {"🍱", "Hộp cơm tre", "200", "Hộp đựng thức ăn từ tre"},
            {"🎫", "Voucher 50k", "250", "Voucher mua sắm xanh"},
            {"🌵", "Cây xanh mini", "300", "Sen đá/xương rồng"},
            {"🥤", "Ống hút inox", "80", "Bộ ống hút thân thiện"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rewards);

        db = new DatabaseHelper(this);
        prefs = getSharedPreferences("EcoTrackPrefs", MODE_PRIVATE);
        userId = prefs.getInt("userId", -1);
        userPoints = prefs.getInt("points", 0);

        setupToolbar();
        initViews();
        loadRewards();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("🎁 Phần Thưởng");
        }
    }

    private void initViews() {
        tvUserPoints = findViewById(R.id.tvUserPoints);
        gridRewards = findViewById(R.id.gridRewards);

        tvUserPoints.setText("Điểm của bạn: " + userPoints);
    }

    private void loadRewards() {
        gridRewards.removeAllViews();

        for (String[] reward : REWARDS) {
            CardView rewardCard = createRewardCard(reward[0], reward[1], Integer.parseInt(reward[2]), reward[3]);
            gridRewards.addView(rewardCard);
        }
    }

    private CardView createRewardCard(String icon, String name, int points, String description) {
        android.view.View view = getLayoutInflater().inflate(R.layout.item_reward, gridRewards, false);

        TextView tvIcon = view.findViewById(R.id.tvRewardIcon);
        TextView tvName = view.findViewById(R.id.tvRewardName);
        TextView tvPoints = view.findViewById(R.id.tvRewardPoints);
        TextView tvDescription = view.findViewById(R.id.tvRewardDescription);
        android.widget.Button btnRedeem = view.findViewById(R.id.btnRedeem);

        tvIcon.setText(icon);
        tvName.setText(name);
        tvPoints.setText(points + " điểm");
        tvDescription.setText(description);

        if (userPoints >= points) {
            btnRedeem.setEnabled(true);
            btnRedeem.setText("Đổi ngay");
            btnRedeem.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#4CAF50")
            ));
        } else {
            btnRedeem.setEnabled(false);
            btnRedeem.setText("Chưa đủ điểm");
            btnRedeem.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#9E9E9E")
            ));
        }

        btnRedeem.setOnClickListener(v -> showRedeemDialog(icon, name, points, description));

        return (CardView) view;
    }

    private void showRedeemDialog(String icon, String name, int points, String description) {
        new AlertDialog.Builder(this)
                .setTitle(icon + " " + name)
                .setMessage("Bạn có chắc muốn đổi phần thưởng này?\n\n" +
                        description + "\n\nĐiểm cần: " + points + "\n" +
                        "Điểm hiện tại: " + userPoints)
                .setPositiveButton("Đổi ngay", (dialog, which) -> redeemReward(name, points))
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void redeemReward(String name, int points) {
        if (userPoints >= points) {
            // Deduct points
            int newPoints = userPoints - points;

            // Update database
            android.database.Cursor cursor = db.getUserById(userId);
            if (cursor != null && cursor.moveToFirst()) {
                int currentPoints = cursor.getInt(cursor.getColumnIndexOrThrow("points"));
                int newLevel = (currentPoints - points) / 100 + 1;

                android.content.ContentValues values = new android.content.ContentValues();
                values.put("points", currentPoints - points);
                values.put("level", newLevel);

                android.database.sqlite.SQLiteDatabase database = db.getWritableDatabase();
                database.update("users", values, "id=?", new String[]{String.valueOf(userId)});

                cursor.close();
            }

            // Update SharedPreferences
            userPoints = newPoints;
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("points", newPoints);
            editor.apply();

            tvUserPoints.setText("Điểm của bạn: " + userPoints);
            loadRewards();

            Toast.makeText(this, "🎉 Đổi thưởng thành công: " + name + "!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Không đủ điểm!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}